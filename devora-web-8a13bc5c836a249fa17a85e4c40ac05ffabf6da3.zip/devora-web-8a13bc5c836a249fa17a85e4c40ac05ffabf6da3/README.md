# Devora Web

Site institucional em React, TypeScript, Vite, Tailwind CSS, Lucide e Motion.

## Executar

```sh
npm install
npm run dev
```

Abra o endereço mostrado pelo Vite. Para validar e gerar a versão de produção:

```sh
npm run check
npm run build
```

## Contatos

Edite `src/config/contact.ts`:

- `WHATSAPP_NUMBER`: número internacional, com DDI e DDD, somente dígitos.
- `CONTACT_EMAIL`: endereço real para receber os projetos.
- `INSTAGRAM_URL`: URL completa do perfil oficial.

Sem contatos configurados, o formulário valida os campos e baixa um resumo em TXT. Nenhum envio é simulado. Ao configurar WhatsApp ou e-mail, ele prepara a mensagem no aplicativo correspondente; o visitante confirma o envio.

O logotipo original está em `public/logo-devora.png`. Para uma versão transparente, substitua o arquivo preservando as proporções e ajuste apenas o enquadramento em `.brand`.

Os projetos são conceitos ilustrativos, sem resultados, clientes ou métricas reais. Os dados dos serviços estão centralizados em `src/App.tsx`; os contatos ficam separados para facilitar a configuração.
