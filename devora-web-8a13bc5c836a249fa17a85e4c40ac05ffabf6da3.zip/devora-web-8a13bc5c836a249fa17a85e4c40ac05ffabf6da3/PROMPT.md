# PROMPT MASTER — LANDING PAGE 3D IMERSIVA: EXPLORAÇÃO DE UMA CAVERNA

## 1. OBJETIVO DO PROJETO

Desenvolva uma landing page extremamente moderna, sofisticada, interativa e visualmente impressionante, utilizando como conceito principal a exploração de uma caverna tridimensional e hiper-realista.

O site deverá proporcionar uma experiência imersiva, na qual o visitante começa observando uma caverna à distância e, conforme rola a página para baixo, aproxima-se progressivamente de sua entrada, atravessa o ambiente e descobre os trabalhos e projetos da empresa apresentados no interior da caverna.

A proposta é fugir completamente do padrão de landing pages convencionais.

Não quero um site que simplesmente utilize uma imagem de caverna como plano de fundo. Quero uma experiência visual que transmita a sensação de estar entrando e explorando um ambiente tridimensional real.

O resultado deverá ter qualidade visual comparável à de sites premiados de agências criativas, estúdios digitais e experiências interativas desenvolvidas com WebGL.

---

## 2. DIREÇÃO DE ARTE E IDENTIDADE VISUAL

### Cenário principal

O ambiente deverá representar uma caverna natural, profunda, misteriosa e extremamente realista.

A caverna deve apresentar:

- Formações rochosas naturais e irregulares.
- Paredes com diferentes profundidades e relevos.
- Texturas realistas de pedras, rochas e minerais.
- Pequenas rachaduras e imperfeições naturais.
- Iluminação ambiental cinematográfica.
- Sombras profundas e realistas.
- Sensação de grande profundidade espacial.
- Variações naturais de cores e materiais.
- Pontos de luz que revelem parcialmente o interior da caverna.

A aparência deverá ser hiper-realista, evitando completamente estilos cartunescos, fantasiosos ou com aparência de jogos antigos.

### Paleta de cores

Utilize uma paleta predominantemente natural e escura:

- Preto profundo.
- Cinza-carvão.
- Cinza-ardósia.
- Marrom-escuro.
- Tons terrosos.
- Pequenos detalhes em âmbar ou dourado quente.

O ambiente deverá transmitir sofisticação, exclusividade, profundidade e mistério.

A iluminação deverá criar contraste entre as áreas escuras e os pontos iluminados, destacando as formações rochosas e os elementos importantes da experiência.

---

## 3. EXPERIÊNCIA INICIAL — PRIMEIRA VISUALIZAÇÃO

Ao acessar o site, o visitante deverá encontrar uma experiência visual impactante.

A primeira seção deverá ocupar praticamente 100% da altura e largura da tela (100vh e 100vw).

### Composição inicial

- Uma caverna gigantesca deverá ocupar o centro da composição.
- A entrada deverá ser claramente identificável.
- O visitante deverá visualizar a caverna de uma perspectiva relativamente distante.
- O ambiente deverá apresentar profundidade e escala.
- A iluminação deverá conduzir naturalmente o olhar para a entrada.

Adicionar uma tipografia elegante e minimalista sobre a cena, sem comprometer a visualização do ambiente.

### Textos sugeridos

Título principal:

"EXPLORE O QUE EXISTE ALÉM."

Subtítulo:

"Uma experiência diferente. Projetos que merecem ser descobertos."

Indicador de navegação:

"ROLE PARA EXPLORAR"

Adicionar um indicador animado de scroll, com uma seta apontando para baixo.

A tipografia deverá ser moderna, elegante e de fácil leitura, preferencialmente com letras maiúsculas, espaçamento refinado e bom contraste.

Os textos devem ser discretos e não competir visualmente com o cenário.

---

## 4. MECÂNICA PRINCIPAL — SCROLL COM APROXIMAÇÃO 3D

Esta é a funcionalidade mais importante de todo o projeto.

Desenvolva uma animação tridimensional controlada diretamente pela rolagem da página.

O scroll deverá funcionar como um controle de câmera dentro do ambiente 3D.

### Etapas da animação

**ETAPA 1 — VISÃO DISTANTE**

O visitante começa visualizando a caverna de longe.

A câmera deverá estar posicionada em uma perspectiva ampla, permitindo visualizar a entrada e parte da formação rochosa ao redor.

**ETAPA 2 — APROXIMAÇÃO**

Conforme o visitante rolar a página, a câmera deverá avançar lentamente em direção à entrada da caverna.

A aproximação deverá ser contínua e sincronizada com o scroll.

As rochas deverão ganhar mais detalhes conforme a câmera se aproxima.

**ETAPA 3 — ENTRADA NA CAVERNA**

A câmera deverá atravessar naturalmente a entrada da caverna.

Nesse momento, a iluminação externa deverá diminuir progressivamente, enquanto a iluminação interna ganha destaque.

O visitante deverá sentir que realmente atravessou a entrada de um ambiente subterrâneo.

**ETAPA 4 — EXPLORAÇÃO INTERNA**

Após entrar, a câmera deverá continuar avançando pelo interior da caverna.

O cenário deverá revelar novas formações rochosas, espaços e pontos de iluminação.

**ETAPA 5 — DESCOBERTA DOS PROJETOS**

Em determinado ponto da exploração, o visitante encontrará uma estrutura de exposição integrada ao cenário.

Essa estrutura será responsável por apresentar os trabalhos da empresa.

### Requisitos da animação

- Movimento extremamente suave.
- Transições cinematográficas.
- Câmera com trajetória previamente definida.
- Sincronização entre scroll e posição da câmera.
- Pequenas mudanças de perspectiva para aumentar o realismo.
- Evitar movimentos bruscos ou exagerados.
- Não utilizar simplesmente zoom de CSS em uma imagem estática.
- A experiência deverá transmitir deslocamento espacial verdadeiro.

O scroll deve ser a principal forma de controlar a experiência, e não apenas um mecanismo para trocar seções.

---

## 5. APRESENTAÇÃO DOS PROJETOS — PRATELEIRAS DENTRO DA CAVERNA

Ao chegar ao interior da caverna, o visitante deverá encontrar os projetos da empresa organizados em uma estrutura semelhante a uma prateleira ou galeria de exposição.

A estrutura deverá parecer fisicamente integrada ao ambiente.

### Design da exposição

Criar uma espécie de galeria de projetos, utilizando elementos como:

- Prateleiras de pedra ou materiais naturais.
- Nichos iluminados nas paredes da caverna.
- Estruturas discretas de exposição.
- Iluminação direcionada para cada projeto.
- Pequenos pontos de luz destacando os trabalhos.

Os projetos deverão ser organizados de maneira visualmente agradável, com espaçamento adequado e hierarquia clara.

### Cada projeto deverá apresentar:

1. Imagem ou miniatura de apresentação.
2. Nome do projeto.
3. Breve descrição.
4. Categoria ou tipo de trabalho.
5. Botão ou interação para visualizar detalhes.

### Interatividade

Ao passar o mouse sobre um projeto:

- A iluminação do nicho deverá aumentar suavemente.
- O projeto deverá receber um pequeno destaque visual.
- Uma descrição resumida poderá aparecer.
- O elemento deverá transmitir a sensação de ser um objeto físico dentro do ambiente.

Em dispositivos móveis, essas interações deverão acontecer por toque.

Ao clicar em um projeto, abrir uma visualização detalhada em formato de modal ou painel imersivo, contendo:

- Imagens maiores.
- Descrição completa.
- Informações relevantes.
- Galeria de imagens, quando aplicável.
- Link para acessar o projeto, quando disponível.

Os projetos deverão ser apresentados de forma dinâmica, evitando aparência de cards convencionais de portfólio.

---

## 6. ELEMENTOS COMPLEMENTARES DA LANDING PAGE

Além da experiência principal, desenvolver elementos que complementem a navegação sem prejudicar a imersão.

### Menu de navegação

Criar um menu minimalista, elegante e discreto.

Sugestões de itens:

- Início.
- Sobre.
- Projetos.
- Serviços.
- Contato.

O menu deverá possuir fundo transparente ou semitransparente, com tipografia clara.

Em dispositivos móveis, utilizar um menu compacto e intuitivo.

### Seção sobre a empresa

Apresentar a empresa de maneira integrada ao ambiente da caverna.

Utilizar uma área visualmente destacada, com iluminação própria e tipografia elegante.

Conteúdo sugerido:

- Quem somos.
- Nossa história.
- Nossa visão.
- Nosso diferencial.

Evitar blocos convencionais de texto. A apresentação deverá manter a identidade visual da experiência.

### Seção de serviços

Apresentar os serviços oferecidos pela empresa utilizando elementos integrados à ambientação.

Cada serviço poderá ocupar um nicho, painel ou ponto de destaque dentro da caverna.

### Seção de contato

Criar uma área final de contato, com uma composição visual impactante.

Incluir:

- Título convidativo.
- Breve mensagem.
- Botão de contato.
- Links para redes sociais.
- Informações de contato da empresa.

Texto sugerido:

"CHEGOU ATÉ AQUI? VAMOS CRIAR ALGO EXTRAORDINÁRIO."

Botão:

"ENTRE EM CONTATO"

---

## 7. TECNOLOGIAS E IMPLEMENTAÇÃO

Priorizar tecnologias modernas que permitam alcançar o nível de realismo e interatividade desejado.

### Tecnologias recomendadas

- React para estrutura da aplicação.
- Three.js para renderização tridimensional.
- React Three Fiber para integração do 3D com React.
- GSAP e ScrollTrigger para animações sincronizadas com o scroll.
- HTML5 e CSS3 para estrutura e estilização.
- WebGL para renderização gráfica.

### Ambiente tridimensional

O cenário deverá ser construído utilizando um modelo 3D de alta qualidade ou uma composição tridimensional desenvolvida especificamente para o projeto.

É permitido utilizar modelos 3D externos, desde que possuam qualidade visual elevada e licença adequada para uso.

Formatos recomendados:

- GLB.
- GLTF.

Utilizar texturas de alta qualidade e materiais PBR para aumentar o realismo das superfícies.

### Câmera

Implementar uma câmera com trajetória controlada pelo progresso do scroll.

A câmera deverá possuir pontos de referência definidos:

- Posição inicial distante.
- Aproximação da entrada.
- Travessia da entrada.
- Exploração interna.
- Posição final próxima da exposição dos projetos.

A interpolação deverá ser suave, utilizando técnicas de easing e interpolação de posição e rotação.

---

## 8. RESPONSIVIDADE — COMPUTADOR E CELULAR

O projeto deverá funcionar perfeitamente em diferentes tamanhos de tela.

### Desktop

- Experiência 3D completa.
- Scroll controlando a trajetória da câmera.
- Alta qualidade visual.
- Interações com hover.
- Menu de navegação completo.

### Mobile

- A experiência deverá ser adaptada para telas menores.
- O movimento de deslizar para baixo deverá controlar a aproximação da câmera.
- Os elementos da exposição deverão ser reorganizados para facilitar a visualização.
- Interações deverão funcionar por toque.
- A câmera deverá possuir uma trajetória adaptada ao formato vertical da tela.
- Evitar textos pequenos e elementos muito próximos.

Não basta reduzir o tamanho da versão desktop. Criar uma composição mobile própria, preservando a experiência de exploração.

---

## 9. DESEMPENHO E OTIMIZAÇÃO

Apesar da complexidade visual, o site deverá funcionar de maneira fluida.

Implementar:

- Carregamento otimizado dos modelos 3D.
- Compressão de texturas.
- Carregamento progressivo de recursos.
- Lazy loading para imagens e conteúdos.
- Otimização de polígonos.
- Controle da resolução de renderização.
- Redução automática da qualidade gráfica em dispositivos mais limitados.
- Prevenção de travamentos durante a rolagem.
- Carregamento inicial rápido.

Adicionar uma tela de carregamento elegante enquanto o cenário 3D é preparado.

A tela deverá mostrar uma animação discreta e uma mensagem como:

"PREPARANDO SUA EXPERIÊNCIA..."

Não permitir que o usuário comece a explorar antes que os recursos essenciais estejam carregados.

---

## 10. ACABAMENTO VISUAL E MICROINTERAÇÕES

Adicionar detalhes que aumentem a qualidade percebida do projeto:

- Transições suaves entre estados.
- Pequenas animações de iluminação.
- Efeitos sutis de profundidade.
- Elementos com transparência controlada.
- Animações de entrada dos textos.
- Indicadores visuais de navegação.
- Feedback visual nos botões.
- Cursor personalizado opcional no desktop.
- Efeitos de destaque nos projetos.

Todos os efeitos devem ser elegantes e moderados.

Evitar excesso de animações, partículas ou elementos decorativos que prejudiquem o desempenho e a experiência.

---

## 11. ACESSIBILIDADE E ALTERNATIVAS DE NAVEGAÇÃO

A experiência deverá continuar acessível mesmo para visitantes que não possam ou não queiram utilizar animações intensas.

Implementar:

- Respeito à preferência de redução de movimento do sistema.
- Navegação por teclado.
- Contraste adequado dos textos.
- Botões com áreas de toque apropriadas.
- Alternativa de navegação sem depender exclusivamente do scroll.
- Conteúdo acessível mesmo quando o WebGL não estiver disponível.

---

## 12. DIRETRIZES IMPORTANTES DE QUALIDADE

Estas instruções devem ser seguidas rigorosamente:

1. Não criar uma landing page genérica com uma imagem de caverna ao fundo.
2. Não substituir a experiência 3D por um simples efeito de zoom em uma fotografia.
3. Não utilizar elementos cartunescos ou modelos visivelmente artificiais.
4. Não criar prateleiras que pareçam cards comuns de um site tradicional.
5. Não utilizar animações bruscas ou movimentos excessivamente rápidos.
6. Não sacrificar a usabilidade em favor dos efeitos visuais.
7. Não deixar a versão mobile como uma adaptação improvisada.
8. Não utilizar imagens, textos ou projetos fictícios como se fossem materiais reais da empresa.
9. Manter uma identidade visual consistente em todas as seções.
10. Garantir que todos os botões e elementos interativos tenham funcionalidades reais.

Caso ainda não existam imagens, textos ou projetos definitivos, utilizar conteúdos demonstrativos claramente identificados e preparados para substituição posterior.

---

## 13. RESULTADO ESPERADO

O resultado final deverá ser uma landing page de alto padrão, com uma experiência visual cinematográfica e interativa.

Imagine o seguinte percurso:

O visitante acessa o site e encontra uma gigantesca caverna à sua frente.

Ele começa a rolar a página e percebe que está se aproximando lentamente da entrada.

Continua rolando e atravessa a abertura da caverna.

O ambiente muda, a iluminação fica mais baixa e novas formações rochosas aparecem.

Ele continua avançando até encontrar uma exposição de trabalhos cuidadosamente organizada dentro do ambiente.

Cada projeto possui seu próprio espaço, iluminação e interação.

O visitante pode explorar os trabalhos, abrir detalhes e conhecer a empresa sem sair da experiência imersiva.

**A sensação final deve ser a de explorar um ambiente tridimensional real, e não simplesmente navegar por uma página da internet.**

A prioridade máxima do desenvolvimento deverá ser a qualidade visual do cenário 3D, a naturalidade da movimentação da câmera e a integração dos projetos ao ambiente.

Crie uma experiência memorável, sofisticada e verdadeiramente diferente das landing pages convencionais.
## 14. REQUISITOS AVANÇADOS DE IMPLEMENTAÇÃO E FIDELIDADE AO CONCEITO

### Geometria 3D verdadeira

A caverna deverá ser construída como um ambiente tridimensional navegável, e não como uma imagem plana com efeitos de zoom.

Utilizar geometria 3D, texturas PBR, iluminação e materiais realistas.

O ambiente deverá possuir profundidade espacial real, permitindo que a câmera percorra seu interior.

### Continuidade espacial

Toda a experiência deverá acontecer em um único ambiente tridimensional contínuo.

A entrada na caverna, a exploração interna e a descoberta dos projetos deverão estar conectadas espacialmente.

Não utilizar mudanças de seção que simulem uma entrada na caverna por meio de simples transições de imagens.

### Sincronização com o scroll

O progresso da página deverá controlar a posição e a orientação da câmera.

A animação deverá ser reversível: se o visitante rolar para cima, a câmera deverá retornar suavemente pelo caminho percorrido.

Evitar saltos de posição, travamentos, movimentos inesperados ou perda de sincronização.

### Integração dos projetos

As prateleiras e os projetos deverão fazer parte do cenário tridimensional, respeitando perspectiva, profundidade, escala, iluminação e posicionamento.

Os projetos deverão parecer objetos expostos fisicamente no ambiente.

### Desenvolvimento e validação

Desenvolver o projeto em etapas:

1. Construir o ambiente 3D da caverna.
2. Implementar e testar a trajetória da câmera.
3. Sincronizar a movimentação com o scroll.
4. Construir a exposição de projetos dentro da caverna.
5. Implementar as interações dos projetos.
6. Desenvolver a versão mobile.
7. Otimizar o desempenho e corrigir problemas.

Não considerar uma etapa concluída enquanto sua funcionalidade principal não estiver funcionando.

### Critério de aceitação

O projeto somente será considerado satisfatório quando for possível abrir a landing page, visualizar a caverna à distância, aproximar-se dela pelo scroll, atravessar sua entrada, percorrer seu interior e encontrar os projetos integrados ao ambiente 3D.

A experiência deverá funcionar tanto na rolagem para baixo quanto na rolagem para cima.