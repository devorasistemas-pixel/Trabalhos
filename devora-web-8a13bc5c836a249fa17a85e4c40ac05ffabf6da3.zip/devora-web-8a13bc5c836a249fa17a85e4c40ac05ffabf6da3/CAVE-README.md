# Devora Web — jornada tridimensional

## Executar

```sh
npm ci
npm run dev
```

Verificações: `npm run test:cave` e `npm run build`. Produção: `npm run build` gera `dist/` para a Vercel.

## Estrutura

- `src/cave/geometry.ts`: entrada, túnel contínuo e rochas procedurais, com normais e UVs.
- `src/cave/engine.ts`: Three.js, materiais PBR, luzes, sombras, expositores, raycasting e descarte de recursos.
- `src/cave/path.ts`: curva espacial, posição/orientação da câmera e interpolação protegida contra deltas de tempo negativos.
- `src/cave/projects.ts`: imagens, títulos, descrições, categorias, links e posições editáveis das obras.
- `src/cave/CaveApp.tsx`: carregamento, navegação, controle de percurso, diálogos e versão acessível.
- `src/cave/cave.css`: composição responsiva.
- `scripts/check-cave.mjs`: verificação de continuidade, retorno e colisões do percurso.
- `public/cave/`: mapas de cor, normal OpenGL, rugosidade e oclusão ambiente em WebP, hospedados localmente.
- `PROMPT.md`: especificação integral fornecida pelo usuário.

## Como funciona

A câmera percorre uma curva Catmull–Rom de aproximadamente 109 unidades: começa em z=30, atravessa a abertura em z=0 e termina em z=-79. A versão vertical mantém o mesmo caminho conectado, com pequeno recuo e campo de visão mais amplo. A distância focal não é usada para simular o avanço; a posição da câmera muda no mundo tridimensional. O piso, as paredes, as rochas e a exposição permanecem no mesmo cenário.

O scroll nativo determina um progresso entre 0 e 1. A interpolação amortecida converge para esse valor sem ultrapassar os extremos. Rolar para cima percorre a curva na direção inversa. Menu, controle deslizante e botões Voltar/Avançar oferecem navegação alternativa.

As obras têm planos texturizados em molduras, bases e suportes de pedra. A seleção usa raycasting, respeitando o bloqueio pelas paredes. O destaque modifica a luz do expositor. Detalhes abrem em diálogo nativo com foco, Escape e links reais. A lista acessível oferece os mesmos trabalhos por teclado ou toque.

## Editar projetos

Altere `projects.ts` e coloque imagens otimizadas em `public/`. `position` define a localização física em unidades do cenário. Após mover uma obra, execute os testes de colisão e revise o enquadramento no navegador. O único trabalho real exibido é Garras de Gata. Os outros dois exemplos são conceitos explicitamente identificados.

## Acessibilidade e compatibilidade

Quem prefere movimento reduzido inicia na versão em documento, sem carregar a cena. Há um botão para entrar voluntariamente em 3D. Se WebGL2 ou os recursos essenciais falharem, a interface oferece o mesmo conteúdo sem 3D. A versão anterior do site continua em `?classico=1`.

## Desempenho

Texturas PBR: aproximadamente 809 KB no total. Three.js e a cena são carregados separadamente da interface; a versão clássica também fica em chunk separado. Geometrias repetidas usam instâncias. A resolução é limitada, sombras são reduzidas no celular e a renderização pausa quando a câmera e os destaques estabilizam. A aba oculta não continua renderizando. Há redução de qualidade quando frames lentos se acumulam.

O cenário é uma composição procedural própria com texturas fotográficas, não um escaneamento 3D de uma caverna real. O teste em navegador não equivale a uma garantia de 60 fps em todo aparelho físico.

## Licença das texturas

[Rock Boulder Dry — Poly Haven](https://polyhaven.com/a/rock_boulder_dry), CC0. Autores: Dimitrios Savva e Rico Cilliers. Licença registrada em `public/cave/LICENSE.txt`.

