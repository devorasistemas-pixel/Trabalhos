import assert from 'node:assert/strict';
import {readFile,writeFile,unlink} from 'node:fs/promises';
import ts from 'typescript';
const temporary=[];
async function module(name){const file=new URL('../src/cave/'+name+'.ts',import.meta.url);const out=new URL('./.check-'+name+'.mjs',import.meta.url);await writeFile(out,ts.transpileModule(await readFile(file,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText);temporary.push(out);return import(out.href+'?'+Date.now());}
try{
 const {cameraPose,clamp01,advanceProgress}=await module('path');const {tunnelGeometry,entranceGeometry,centerX,radiusX}=await module('geometry');const {projects}=await module('projects');
 for(const dt of [-10,-.001,0,.016,50]){const p=advanceProgress(.2,.8,dt);assert(p>=.2&&p<=.8,'Invalid timing caused progress overflow');}let progress=.2;for(let i=0;i<300;i++)progress=advanceProgress(progress,1,.016);assert(Math.abs(progress-1)<.0001);for(let i=0;i<300;i++)progress=advanceProgress(progress,0,.016);assert(progress<.0001);
 for(const mobile of [false,true]){
  let previous=null;const outward=[];
  for(let i=0;i<=2000;i++){
   const {position,target}=cameraPose(i/2000,mobile);assert([...position,...target].every(Number.isFinite));assert(position.distanceTo(target)>.1);
   if(previous)assert(position.distanceTo(previous)<.12,'Camera jump');
   if(position.z<0){const ellipse=((position.x-centerX(position.z))/radiusX(position.z))**2+((position.y-4.9)/4.9)**2;assert(ellipse<.72,'Camera near cave wall');assert(position.y>1.8,'Camera clips floor');}
   for(const p of projects){const [x,y,z]=p.position;assert(!(Math.abs(position.z-z)<.6&&Math.abs(position.x-x)<2.8&&Math.abs(position.y-y)<2.2),'Camera hits exhibit');}
   outward.push(position.toArray());previous=position;
  }
  for(let i=2000;i>=0;i--)assert.deepEqual(cameraPose(i/2000,mobile).position.toArray(),outward[i],'Return path differs');
  assert(cameraPose(0,mobile).position.z>20);assert(cameraPose(1,mobile).position.z< -75);
 }
 for(const make of [tunnelGeometry,entranceGeometry]){const geometry=make();for(const name of ['position','normal','uv'])assert([...geometry.getAttribute(name).array].every(Number.isFinite));assert(geometry.index.count>10000);geometry.dispose();}
 assert.equal(clamp01(-1),0);assert.equal(clamp01(2),1);assert.equal(projects.filter(p=>p.real).length,1);assert(projects.filter(p=>!p.real).every(p=>p.category.includes('ILUSTRATIVO')));
 console.log('PASS: 4,002 poses; reversibility; continuity; wall/floor/exhibit clearance; finite geometry/normals/UVs; project labeling.');
}finally{await Promise.all(temporary.map(file=>unlink(file)));}


