import {mkdir,readFile,writeFile} from 'node:fs/promises';
import {createServer} from 'vite';
import React from 'react';
import {renderToString} from 'react-dom/server';

const origin = 'https://devora-web-hazel.vercel.app';
const server = await createServer({logLevel:'error',server:{middlewareMode:true,hmr:false},appType:'custom'});
const escape = value => value.replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;').replaceAll('>','&gt;');
try {
  const {default:App} = await server.ssrLoadModule('/src/App.tsx');
  const {catalog,offerUrl,pageMeta} = await server.ssrLoadModule('/src/config/catalog.ts');
  const routes = ['/', '/servicos/', '/sobre/', '/contato/', ...catalog.map(offerUrl)];
  const dist = new URL('../dist/',import.meta.url);
  let template = await readFile(new URL('index.html',dist),'utf8');
  if (process.env.VERCEL_ENV==='preview') template=template.replace('content="index, follow, max-image-preview:large"','content="noindex, nofollow"');
  if (!template.includes('<div id="root"></div>')) throw new Error('Empty root not found');
  for (const path of routes) {
    let html=template;
    const meta=pageMeta(path);
    if(meta) {
      const title=escape(meta.title+' | Devora Web');
      const description=escape(meta.description);
      html=html.replace(/<title>.*?<\/title>/, '<title>'+title+'</title>');
      for(const [name,value] of [['description',description],['og:title',title],['og:description',description],['og:url',origin+path],['twitter:title',title],['twitter:description',description]]) {
        html=html.replace(new RegExp('(<meta (?:name|property)="'+name+'" content=")[^"]*'),(_,prefix)=>prefix+value);
      }
      html=html.replace(/(<link rel="canonical" href=")[^"]*/,(_,prefix)=>prefix+origin+path);
    }
    const content=renderToString(React.createElement(App,{path})).replace(/style="opacity:0;transform:[^"]*"/g,'style="opacity:1"');
    const directory=new URL('.'+path,dist);
    await mkdir(directory,{recursive:true});
    await writeFile(new URL('index.html',directory),html.replace('<div id="root"></div>','<div id="root">'+content+'</div>'));
  }
  const sitemapRoutes=[...routes,'/politica-de-privacidade/','/politica-de-cookies/'];
  await writeFile(new URL('sitemap.xml',dist),'<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+sitemapRoutes.map(path=>'<url><loc>'+origin+path+'</loc></url>').join('')+'</urlset>');
  console.log('Prerendered '+routes.length+' pages and updated sitemap.');
} finally {await server.close();}

