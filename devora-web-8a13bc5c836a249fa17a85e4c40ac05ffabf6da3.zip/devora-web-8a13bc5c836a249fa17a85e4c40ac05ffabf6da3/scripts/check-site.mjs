import assert from 'node:assert/strict';
import {readFile,stat} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {createServer} from 'vite';
const server=await createServer({logLevel:'error',server:{middlewareMode:true,hmr:false},appType:'custom'});
let checks=0;const check=(condition,message)=>{assert.ok(condition,message);checks++;};
try{
 const {plans,maintenance}=await server.ssrLoadModule('/src/config/plans.ts');
 const {commercialLink}=await server.ssrLoadModule('/src/config/contact.ts');
 check(plans.length===5&&maintenance.length===2,'Five services and two maintenance offers');
 const prices={'normal':'397,00','premium':'497,00','sistema':'1.490,00','ia':'990,00','whatsapp':'199,90'};
 for(const p of plans){check(p.price===prices[p.id],p.id+' official price');check(p.features.length>=6&&p.conditions.length>=2,p.id+' scope and conditions');}
 check(plans[2].recurring==='119,00','Mandatory system monthly cost');
 check(plans[1].conditions.join(' ').includes('40,00')&&!plans[1].conditions.join(' ').includes('gratuito'),'Premium renewal is explicit');
 check(maintenance[0].price==='39,90'&&maintenance[1].price==='69,90','Maintenance prices');
 for(const p of [...plans,...maintenance]){const url=new URL(commercialLink(p.message));check(url.protocol==='https:'&&url.hostname==='wa.me'&&url.pathname==='/5543998229880','Official WhatsApp '+p.id);check(url.searchParams.get('text')===p.message,'Message encoding '+p.id);}
 const index=await readFile('dist/index.html','utf8');
 check(index.includes('google-site-verification')&&index.includes('dISSXpzcVc_'),'Existing Google verification preserved');
 check(!index.includes('Precisão técnica.')&&!index.includes('Presença singular.'),'Duplicate services not restored');
 check(!index.includes('Garras de Gata')&&index.includes('Studio VIP Lounge'),'Removed Garras de Gata and preserved Studio VIP Lounge');
 check(index.includes('1.490,00')&&!index.includes('1.499,00')&&index.includes('119,00'),'Prerendered prices correct');
 check(index.includes('39,90')&&index.includes('69,90'),'Maintenance prerendered');
 check(!index.includes('fonts.googleapis.com')&&!index.includes('fonts.gstatic.com'),'No remote font requests');
 const json=index.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)[1];const schema=JSON.parse(json);
 check(schema['@graph'][0]['@type']==='Organization'&&!json.includes('aggregateRating'),'Genuine structured data without invented ratings');
 const source=await readFile('index.html','utf8');const originalJson=source.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/)[1];
 const config=JSON.parse(await readFile('vercel.json','utf8'));const csp=config.headers.find(h=>h.source==='/').headers[0].value;
 check(csp.includes(createHash('sha256').update(originalJson).digest('base64')),'CSP permits exact JSON-LD');
 for(const path of ['favicon.ico','favicon-48.png','apple-touch-icon.png','icon-192.png','icon-512.png','logo-lockup.webp','logo-organization.png','compartilhar-devora.jpg','fonts/manrope-variable.ttf','politica-de-privacidade/index.html','politica-de-cookies/index.html'])check((await stat('dist/'+path)).size>0,'Public resource '+path);
 for(const route of ['politica-de-privacidade','politica-de-cookies']){const html=await readFile('dist/'+route+'/index.html','utf8');check(html.includes('rel="canonical"')&&html.includes('5543998229880'),'Legal route '+route);}
 console.log(`${checks} site checks passed.`);
}finally{await server.close();}

