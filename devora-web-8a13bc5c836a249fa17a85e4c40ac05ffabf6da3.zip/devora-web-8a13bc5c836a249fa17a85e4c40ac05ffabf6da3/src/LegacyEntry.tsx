import App from './App';
import './styles.css';
import './white-theme.css';
export default App;
import './reference-theme.css';

import './components/pricing.css';

import './premium.css';
import './glass.css';
import './institutional.css';

