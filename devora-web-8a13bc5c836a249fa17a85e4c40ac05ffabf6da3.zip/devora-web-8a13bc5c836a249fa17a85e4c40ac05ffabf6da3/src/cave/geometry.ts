import * as T from 'three';
export function centerX(z:number){return Math.sin(z*.065)*.65;}
export function radiusX(z:number){return 6+7/(1+Math.exp((z+42)/3));}
export function rockNoise(x:number,y:number,z:number){return Math.sin(x*1.7+Math.sin(z*.5))*Math.cos(y*1.9+z*.27)*.27+Math.sin(x*5.3+y*4.1+z*2.3)*.085;}
export function contour(a:number,z:number){return 1+Math.sin(a*3+z*.017)*.09+Math.cos(a*7-z*.026)*.045+Math.sin(a*11+z*.11)*.022;} 
export function tunnelGeometry(){
 const positions:number[]=[],uv:number[]=[],indices:number[]=[];const rings=220,sides=80;
 for(let j=0;j<=rings;j++){const z=-j*96/rings;
  for(let i=0;i<=sides;i++){const a=i/sides*Math.PI*2,n=rockNoise(Math.cos(a)*5,Math.sin(a)*5,z),r=contour(a,z)+n*.18;
   const x=centerX(z)+Math.cos(a)*radiusX(z)*r,y=4.9+Math.sin(a)*4.9*r;
   positions.push(x,Math.max(-.3,y),z);uv.push(i/sides*9,j/rings*28);
   if(j<rings&&i<sides){const k=j*(sides+1)+i;indices.push(k,k+1,k+sides+1,k+1,k+sides+2,k+sides+1);}
  }
 }
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(positions,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.setIndex(indices);g.computeVertexNormals();return g;
}
export function entranceGeometry(){
 const p:number[]=[],uv:number[]=[],idx:number[]=[];const bands=20,sides=100;
 for(let j=0;j<=bands;j++)for(let i=0;i<=sides;i++){
  const a=i/sides*Math.PI*2,f=j/bands,rx=6*contour(a,0)+(19-6)*f,ry=4.9*contour(a,0)+(13-4.9)*f;
  const n=rockNoise(Math.cos(a)*rx,Math.sin(a)*ry,f*4);
  p.push(Math.cos(a)*rx+n,4.9+Math.sin(a)*ry+n,-f*5+n*.8);uv.push((Math.cos(a)*rx)/3,(Math.sin(a)*ry)/3);
  if(j<bands&&i<sides){const k=j*(sides+1)+i;idx.push(k,k+1,k+sides+1,k+1,k+sides+2,k+sides+1);}
 }
 const g=new T.BufferGeometry();g.setAttribute('position',new T.Float32BufferAttribute(p,3));g.setAttribute('uv',new T.Float32BufferAttribute(uv,2));g.setIndex(idx);g.computeVertexNormals();return g;
}
export function boulderGeometry(){
 const g=new T.IcosahedronGeometry(1,3),a=g.attributes.position;
 for(let i=0;i<a.count;i++){const v=new T.Vector3().fromBufferAttribute(a,i),r=1+rockNoise(v.x*2,v.y*2,v.z*2)*.5;v.multiplyScalar(r);a.setXYZ(i,v.x,v.y,v.z);}
 g.computeVertexNormals();return g;
}






