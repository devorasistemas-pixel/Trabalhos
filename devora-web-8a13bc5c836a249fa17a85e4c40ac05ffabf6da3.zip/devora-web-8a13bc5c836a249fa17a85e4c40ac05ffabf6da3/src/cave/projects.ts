export type CaveProject={id:string;title:string;category:string;summary:string;description:string;image?:string;images:string[];url?:string;real:boolean;position:[number,number,number]};
// Edit these fields to update the physical exhibits and their detail dialogs.
export const projects:CaveProject[]=[
 {id:'garras',title:'Garras de Gata',category:'SITE PROFISSIONAL · BELEZA',summary:'Personalidade em cada detalhe.',description:'Um site com identidade própria para apresentar o trabalho de nail design, os serviços e o agendamento pelo WhatsApp. Feedback da cliente: “Eu amei muito!” e “Achei incrível”.',image:'/garras-de-gata.webp',images:['/garras-de-gata.webp'],url:'https://prototipo-garras-de-gata.vercel.app/',real:true,position:[-3.6,3.5,-60]},
 {id:'institucional',title:'Presença digital',category:'CONCEITO ILUSTRATIVO · SITE',summary:'Uma exploração de design editorial.',description:'Conceito demonstrativo de um site institucional. Apresenta uma possibilidade de organização de conteúdo, identidade e navegação. Não representa um cliente ou projeto contratado.',images:[],real:false,position:[3.6,3.5,-74]},
 {id:'sistema',title:'Operação conectada',category:'CONCEITO ILUSTRATIVO · SISTEMA',summary:'Clareza para acompanhar o negócio.',description:'Conceito demonstrativo de um sistema web com indicadores e fluxos organizados. Todos os elementos exibidos são ilustrativos. Não representa um cliente ou resultado real.',images:[],real:false,position:[-3.6,3.5,-86]}
];




