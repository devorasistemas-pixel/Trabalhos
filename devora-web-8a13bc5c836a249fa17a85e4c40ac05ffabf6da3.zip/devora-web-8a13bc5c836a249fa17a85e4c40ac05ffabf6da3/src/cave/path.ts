import {CatmullRomCurve3, Vector3, MathUtils} from 'three';

export const clamp01=(n:number)=>Math.min(1,Math.max(0,n));
export const cameraPath=new CatmullRomCurve3([
 new Vector3(0,4.2,30),new Vector3(.4,3.4,16),new Vector3(0,2.8,3),
 new Vector3(-.7,2.65,-13),new Vector3(.8,2.7,-31),new Vector3(0,2.7,-46),
 new Vector3(-.6,2.9,-54),new Vector3(.7,2.85,-67),new Vector3(-.3,2.9,-79)
],false,'centripetal');
export function advanceProgress(current:number,target:number,dt:number){return clamp01(MathUtils.damp(clamp01(current),clamp01(target),9,Math.max(.001,Math.min(dt,.05))));}
export const stages=[{p:0,label:'Início'},{p:.3,label:'Entrada'},{p:.51,label:'Sobre'},{p:.69,label:'Projetos'},{p:.84,label:'Serviços'},{p:1,label:'Contato'}];
export function cameraPose(progress:number,mobile=false){
 const p=clamp01(progress),position=cameraPath.getPointAt(p);
 // Portrait uses a slightly raised eye, the exact same continuous passage.
 if(mobile){position.y+=.18;position.z+=2.8;}
 const target=cameraPath.getPointAt(Math.min(1,p+.045));
 if(p>.63){const f=clamp01((p-.63)/.12);target.lerp(new Vector3(-3.6,3.5,-60),f*(1-clamp01((p-.76)/.07)));}
 if(p>.8){target.lerp(new Vector3(3.6,3.5,-74),clamp01((p-.8)/.05)*(1-clamp01((p-.9)/.04)));}
 if(p>.92)target.lerp(new Vector3(-3.6,3.5,-86),clamp01((p-.92)/.08));
 if(target.distanceTo(position)<.1)target.z-=3;
 return {position,target};
}






