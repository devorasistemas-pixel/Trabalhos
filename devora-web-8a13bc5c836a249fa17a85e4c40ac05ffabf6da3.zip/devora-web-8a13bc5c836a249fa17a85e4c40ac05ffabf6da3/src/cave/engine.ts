import * as T from 'three';
import {cameraPose,clamp01,advanceProgress} from './path';
import {tunnelGeometry,entranceGeometry,boulderGeometry,centerX,radiusX,contour} from './geometry';
import {projects,type CaveProject} from './projects';
type Options={reduced:boolean;onProgress:(n:number)=>void;onReady:()=>void;onError:()=>void;onSelect:(id:string)=>void;onFrame:(p:number)=>void};
export async function createCave(host:HTMLElement,options:Options){
 const renderer=new T.WebGLRenderer({antialias:true,alpha:false,powerPreference:'high-performance'});
 renderer.setClearColor(0x121414);renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.05;
 const mobile=()=>innerWidth<760;let low=mobile(),disposed=false,frame=0,current=0,target=0,last=performance.now(),slowFrames=0;
 renderer.setPixelRatio(Math.min(devicePixelRatio,low?1.25:1.6));renderer.shadowMap.enabled=!low;renderer.shadowMap.type=T.PCFShadowMap;
 renderer.domElement.setAttribute('aria-label','Caverna tridimensional da Devora Web. Use o menu para navegar e a lista para abrir projetos.');renderer.domElement.setAttribute('role','img');
 host.appendChild(renderer.domElement);
 const scene=new T.Scene();scene.background=new T.Color(0x1a2020);scene.fog=new T.FogExp2(0x151b1c,.018);
 const camera=new T.PerspectiveCamera(52,1,.08,180);
 const manager=new T.LoadingManager();manager.onProgress=(_,loaded,total)=>options.onProgress(loaded/total*.9);
 const loader=new T.TextureLoader(manager),textures:T.Texture[]=[];
 const load=async(path:string,color=false)=>{const t=await loader.loadAsync(path);if(disposed){t.dispose();throw Error('disposed');}t.colorSpace=color?T.SRGBColorSpace:T.NoColorSpace;t.wrapS=t.wrapT=T.RepeatWrapping;t.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());textures.push(t);return t;};
 const cleanup=()=>{disposed=true;cancelAnimationFrame(frame);renderer.dispose();renderer.forceContextLoss();renderer.domElement.remove();textures.forEach(t=>t.dispose());scene.traverse(o=>{if(o instanceof T.Mesh){o.geometry.dispose();const materials=Array.isArray(o.material)?o.material:[o.material];materials.forEach(m=>m.dispose());}});};
 try{
 const [map,normal,rough,ao,mountainPhoto]=await Promise.all([load('/cave/Diffuse.webp',true),load('/cave/nor_gl.webp'),load('/cave/rough.webp'),load('/cave/AO.webp'),load('/cave/mountain-reference.png',true)]);
 mountainPhoto.wrapS=mountainPhoto.wrapT=T.ClampToEdgeWrapping;
 // The user's photograph is an exterior backdrop only; the navigable cave stays volumetric.
 const mountainMaterial=new T.ShaderMaterial({uniforms:{photo:{value:mountainPhoto},opacity:{value:1}},transparent:false,depthWrite:false,toneMapped:false,
  vertexShader:'varying vec2 mountainUv;void main(){mountainUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
  fragmentShader:'uniform sampler2D photo;uniform float opacity;varying vec2 mountainUv;void main(){vec3 color=texture2D(photo,mountainUv).rgb;float edge=smoothstep(0.,.12,mountainUv.x)*(1.-smoothstep(.88,1.,mountainUv.x))*smoothstep(0.,.08,mountainUv.y)*(1.-smoothstep(.92,1.,mountainUv.y));gl_FragColor=vec4(mix(vec3(.0103,.0144,.0144),color,edge*opacity),1.);#include <colorspace_fragment>}'.replace('#include','\n#include')});
 const mountain=new T.Mesh(new T.PlaneGeometry(66,66*482/327),mountainMaterial);mountain.position.set(0,13,-18);mountain.renderOrder=-10;scene.add(mountain);
 const rock=new T.MeshStandardMaterial({map,normalMap:normal,normalScale:new T.Vector2(.85,.85),roughnessMap:rough,roughness:.95,aoMap:ao,aoMapIntensity:.6,color:0x8e8a80,side:T.DoubleSide});
 const darkRock=rock.clone();darkRock.color.setHex(0x66645e);
 const tunnel=new T.Mesh(tunnelGeometry(),rock);tunnel.receiveShadow=true;scene.add(tunnel);
 const facade=new T.Mesh(entranceGeometry(),rock);facade.castShadow=true;facade.receiveShadow=true;scene.add(facade);
 const groundMap=map.clone();groundMap.repeat.set(28,28);textures.push(groundMap);
 const groundMat=rock.clone();groundMat.map=groundMap;groundMat.color.setHex(0x6a6962);
 const ground=new T.Mesh(new T.PlaneGeometry(180,200,32,32),groundMat);ground.rotation.x=-Math.PI/2;ground.position.set(0,-.22,-35);ground.receiveShadow=true;scene.add(ground);
 let seed=211;const random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
 const rockGeo=boulderGeometry(),rocks=new T.InstancedMesh(rockGeo,rock,260),dummy=new T.Object3D();
 for(let i=0;i<260;i++){
  const z=i<65?4+random()*15:-random()*94;let x;
  if(i<65)x=(random()<.5?-1:1)*(7+random()*15);else x=centerX(z)+(random()<.5?-1:1)*(radiusX(z)-.5+random()*1.3);
  const s=.3+random()*1.7;dummy.position.set(x,s*.35-.1,z);dummy.scale.set(s*(.7+random()),s*(.6+random()),s*(.7+random()));dummy.rotation.set(random(),random()*6,random());dummy.updateMatrix();rocks.setMatrixAt(i,dummy.matrix);
 }
 rocks.castShadow=true;rocks.receiveShadow=true;scene.add(rocks);
 // Rough mineral formations keep the center corridor free for the entire path.
 const formations=new T.InstancedMesh(boulderGeometry(),darkRock,110);
 for(let i=0;i<110;i++){const z=-5-random()*87,side=random()<.5?-1:1,x=centerX(z)+side*(3.5+random()*1.4),ceiling=i%2===0;
  const a=side>0?.8+random()*.5:Math.PI-(.8+random()*.5);const r=contour(a,z);dummy.position.set(ceiling?centerX(z)+Math.cos(a)*radiusX(z)*r:x,ceiling?4.9+Math.sin(a)*4.9*r:random()*.2,z);dummy.scale.set(.25+random()*.4,.65+random()*1.2,.25+random()*.3);dummy.rotation.set(ceiling?Math.PI:0,random()*6,side*.12);dummy.updateMatrix();formations.setMatrixAt(i,dummy.matrix);}
 formations.castShadow=true;scene.add(formations);
 const back=new T.Mesh(new T.SphereGeometry(13,32,24),darkRock);back.scale.set(1,1,.4);back.position.set(0,4,-99);scene.add(back);
 const hemi=new T.HemisphereLight(0xb7c8cf,0x3f3024,1.1);scene.add(hemi);
 const sun=new T.DirectionalLight(0xe7edf0,3);sun.position.set(-12,22,18);sun.castShadow=!low;sun.shadow.mapSize.set(2048,2048);sun.shadow.camera.left=-22;sun.shadow.camera.right=22;sun.shadow.camera.top=22;sun.shadow.camera.bottom=-15;sun.shadow.bias=-.001;scene.add(sun);
 const lamps:T.PointLight[]=[];
 for(let i=0;i<9;i++){const z=-5-i*10,side=i%2?1:-1;const light=new T.PointLight(0xffd1a3,85,24,2);light.position.set(centerX(z)+side*4.3,4.4,z);scene.add(light);lamps.push(light);
  const housing=new T.Mesh(new T.CylinderGeometry(.09,.09,.65,10),new T.MeshStandardMaterial({color:0x292723,roughness:.7}));housing.position.copy(light.position);scene.add(housing);
  const bulb=new T.Mesh(new T.SphereGeometry(.11,10,8),new T.MeshBasicMaterial({color:0xffd7a0}));bulb.position.copy(light.position);scene.add(bulb);
 }
 const panels:T.Mesh[]=[],spots:T.SpotLight[]=[];
 const text=(ctx:CanvasRenderingContext2D,value:string,x:number,y:number,width:number,line:number)=>{let str='';for(const word of value.split(' ')){if(ctx.measureText(str+word).width>width){ctx.fillText(str,x,y);str='';y+=line;}str+=word+' ';}ctx.fillText(str,x,y);return y;};
 async function panelTexture(project:CaveProject){
  const canvas=document.createElement('canvas');canvas.width=1024;canvas.height=768;const ctx=canvas.getContext('2d')!;
  ctx.fillStyle='#171b1b';ctx.fillRect(0,0,1024,768);
  if(project.image){const image=await new Promise<HTMLImageElement>((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=reject;img.src=project.image!;});ctx.drawImage(image,32,32,960,540);}
  else{ctx.fillStyle='#e8edf0';ctx.fillRect(32,32,960,540);ctx.fillStyle='#123659';ctx.font='56px Georgia';ctx.fillText(project.title,80,140);ctx.font='24px sans-serif';ctx.fillText('CONCEITO ILUSTRATIVO',80,195);for(let i=0;i<3;i++){ctx.fillStyle=['#c8d8e8','#a2bcdb','#7d9dbf'][i];ctx.fillRect(80+i*300,260,255,180);}ctx.fillStyle='#284766';ctx.font='24px sans-serif';ctx.fillText('DEVORA WEB / EXPLORAÇÕES DE DESIGN',80,515);}
  ctx.fillStyle='#d7b68b';ctx.font='19px sans-serif';ctx.fillText(project.real?'PROJETO REAL':'CONCEITO ILUSTRATIVO',38,614);
  ctx.fillStyle='#f6f0e6';ctx.font='43px Georgia';ctx.fillText(project.title,38,672);ctx.font='23px sans-serif';text(ctx,project.summary,38,716,900,29);
  const t=new T.CanvasTexture(canvas);t.colorSpace=T.SRGBColorSpace;textures.push(t);return t;
 }
 for(const project of projects){
  const group=new T.Group();group.position.set(...project.position);
  const support=new T.Mesh(new T.BoxGeometry(5.65,.38,2.4),rock);support.position.set(0,-2,0);support.castShadow=true;support.receiveShadow=true;group.add(support);
  for(const x of [-2.1,2.1]){const pedestal=new T.Mesh(new T.BoxGeometry(.6,1.4,1.4),darkRock);pedestal.position.set(x,-2.8,-.2);group.add(pedestal);}
  const backing=new T.Mesh(new T.BoxGeometry(5.55,4.25,.5),darkRock);backing.position.z=-.32;group.add(backing);
  const panel=new T.Mesh(new T.PlaneGeometry(5.12,3.84),new T.MeshStandardMaterial({map:await panelTexture(project),roughness:.6,emissive:0xffffff,emissiveIntensity:.32,emissiveMap:null}));
  // A low emissive contribution preserves image fidelity without floating UI.
  (panel.material as T.MeshStandardMaterial).emissiveMap=(panel.material as T.MeshStandardMaterial).map;
  panel.userData.project=project.id;panel.position.z=.02;group.add(panel);panels.push(panel);
  const bronze=new T.MeshStandardMaterial({color:0x8c7353,metalness:.65,roughness:.45});
  for(const x of [-2.63,2.63]){const bar=new T.Mesh(new T.BoxGeometry(.11,4.02,.12),bronze);bar.position.set(x,0,.1);group.add(bar);}for(const y of [-2,2]){const bar=new T.Mesh(new T.BoxGeometry(5.38,.1,.12),bronze);bar.position.set(0,y,.1);group.add(bar);}
  scene.add(group);
  const spot=new T.SpotLight(0xffe4c6,150,15,.72,.65,2);spot.position.set(project.position[0],7,project.position[2]+3);spot.target=panel;spot.castShadow=!low&&project.real;spot.shadow.mapSize.set(1024,1024);scene.add(spot);spots.push(spot);
 }
 const ray=new T.Raycaster(),mouse=new T.Vector2();let hovered=-1;
 const pick=(e:PointerEvent)=>{const rect=renderer.domElement.getBoundingClientRect();mouse.set((e.clientX-rect.left)/rect.width*2-1,-(e.clientY-rect.top)/rect.height*2+1);ray.setFromCamera(mouse,camera);const hit=ray.intersectObjects(panels,false)[0];if(!hit)return -1;const wall=ray.intersectObjects([tunnel,facade],false)[0];if(wall&&wall.distance<hit.distance-.2)return -1;return panels.indexOf(hit.object as T.Mesh);};
 let downX=0,downY=0;
 const down=(e:PointerEvent)=>{downX=e.clientX;downY=e.clientY;};
 const click=(e:PointerEvent)=>{if(Math.hypot(e.clientX-downX,e.clientY-downY)>12)return;const index=pick(e);if(index>=0)options.onSelect(projects[index].id);};
 const move=(e:PointerEvent)=>{hovered=pick(e);renderer.domElement.style.cursor=hovered>=0?'pointer':'auto';schedule();};
 const scroll=()=>{target=clamp01(scrollY/Math.max(1,document.documentElement.scrollHeight-innerHeight));schedule();};
 const resize=()=>{renderer.setSize(host.clientWidth,host.clientHeight);camera.aspect=host.clientWidth/host.clientHeight;camera.fov=mobile()?74:52;camera.updateProjectionMatrix();schedule();};
 let previousReported=-1;
 function render(now:number){frame=0;if(disposed||document.hidden)return;const dt=Math.max(.001,Math.min((now-last)/1000,.05));last=now;current=options.reduced?target:advanceProgress(current,target,dt);if(Math.abs(current-target)<.00002)current=target;
  mountainMaterial.uniforms.opacity.value=1-T.MathUtils.smoothstep(current,.07,.24);mountain.visible=current<.24;const pose=cameraPose(current,mobile());camera.position.copy(pose.position);camera.lookAt(pose.target);
  const inside=T.MathUtils.smoothstep(-camera.position.z,-1,15);hemi.intensity=T.MathUtils.lerp(1.1,.18,inside);sun.intensity=T.MathUtils.lerp(3,.4,inside);(scene.fog as T.FogExp2).density=T.MathUtils.lerp(.018,.026,inside);
  spots.forEach((s,i)=>s.intensity=T.MathUtils.damp(s.intensity,hovered===i?240:150,7,dt));
  renderer.render(scene,camera);
  host.dataset.camera=JSON.stringify({p:Number(current.toFixed(5)),x:Number(camera.position.x.toFixed(3)),y:Number(camera.position.y.toFixed(3)),z:Number(camera.position.z.toFixed(3)),drawCalls:renderer.info.render.calls,triangles:renderer.info.render.triangles,quality:low?'leve':'completa'});
  if(Math.abs(current-previousReported)>.002){previousReported=current;options.onFrame(current);}
  if(dt>.036&&current!==target&&!low){slowFrames++;if(slowFrames>35){low=true;renderer.setPixelRatio(1);renderer.shadowMap.enabled=false;}}
  if(current!==target||spots.some((s,i)=>Math.abs(s.intensity-(hovered===i?240:150))>1))schedule();
 }
 function schedule(){if(!frame&&!disposed){last=performance.now();frame=requestAnimationFrame(render);}}
 const visibility=()=>{if(!document.hidden)schedule();};
 const contextLost=(e:Event)=>{e.preventDefault();options.onError();};
 renderer.domElement.addEventListener('pointerdown',down);renderer.domElement.addEventListener('pointerup',click);renderer.domElement.addEventListener('pointermove',move);renderer.domElement.addEventListener('webglcontextlost',contextLost);
 window.addEventListener('scroll',scroll,{passive:true});window.addEventListener('resize',resize);document.addEventListener('visibilitychange',visibility);
 resize();scroll();await renderer.compileAsync(scene,camera);cancelAnimationFrame(frame);frame=0;render(performance.now());options.onProgress(1);options.onReady();
 return ()=>{window.removeEventListener('scroll',scroll);window.removeEventListener('resize',resize);document.removeEventListener('visibilitychange',visibility);renderer.domElement.removeEventListener('pointerdown',down);renderer.domElement.removeEventListener('pointerup',click);renderer.domElement.removeEventListener('pointermove',move);renderer.domElement.removeEventListener('webglcontextlost',contextLost);cleanup();};
 }catch(e){cleanup();throw e;}
}










