import {useEffect, useRef} from 'react';
import {useReducedMotion} from 'motion/react';
import './mountain-scene.css';

// A real, locally generated WebGL terrain. No model, texture or CDN request.
export default function MountainScene(){
 const canvasRef=useRef<HTMLCanvasElement>(null);
 const reduced=useReducedMotion();
 useEffect(()=>{
  const canvas=canvasRef.current;
  if(!canvas)return;
  const gl=canvas.getContext('webgl',{alpha:true,antialias:true,powerPreference:'low-power'});
  if(!gl)return;
  let frame=0,disposed=false,ready=false;
  const shaders:WebGLShader[]=[];
  let program:WebGLProgram|null=null,buffer:WebGLBuffer|null=null;
  const compile=(type:number,source:string)=>{
   const shader=gl.createShader(type);if(!shader)throw Error('Shader unavailable');shaders.push(shader);
   gl.shaderSource(shader,source);gl.compileShader(shader);if(!gl.getShaderParameter(shader,gl.COMPILE_STATUS))throw Error('Shader compilation failed');return shader;
  };
  try{
   const vertex=compile(gl.VERTEX_SHADER,`
    attribute vec3 position; attribute vec3 normal;
    uniform float yaw; uniform float pitch; uniform float aspect; uniform float travel;
    varying vec3 vNormal; varying vec3 vWorld; varying float vDistance; varying float vEdge;
    void main(){
     mat3 ry=mat3(cos(yaw),0.,-sin(yaw),0.,1.,0.,sin(yaw),0.,cos(yaw));
     mat3 rx=mat3(1.,0.,0.,0.,cos(pitch),sin(pitch),0.,-sin(pitch),cos(pitch));
     vec3 p=ry*position; vWorld=p; vNormal=ry*normal; vEdge=(1.-smoothstep(5.,12.,position.z))*(1.-smoothstep(13.,18.,abs(position.x)))*(1.-smoothstep(8.,12.,-position.z));
     p=rx*p; p.x+=aspect>1.?4.4:0.8; p.y-=2.1+travel*.55; p.z-=20.-travel*1.4;
     vDistance=-p.z;
     float f=aspect>1.?1.65:1.3;
     gl_Position=vec4(p.x*f/aspect,p.y*f,-1.002*p.z-.2002,-p.z);
    }`);
   const fragment=compile(gl.FRAGMENT_SHADER,`
    precision mediump float;
    varying vec3 vNormal; varying vec3 vWorld; varying float vDistance; varying float vEdge;
    void main(){
     vec3 n=normalize(vNormal);
     float key=max(dot(n,normalize(vec3(-.7,1.,.6))),0.);
     float rim=pow(max(dot(n,normalize(vec3(1.,.5,-.8))),0.),2.);
     float height=smoothstep(-1.,5.,vWorld.y);
     vec3 color=vec3(.025,.036,.053)+key*vec3(.07,.105,.15);
     color+=rim*vec3(.018,.12,.34)*(0.35+height*.65);
     color+=pow(key,6.)*height*vec3(.035,.06,.09);
     float fog=smoothstep(17.,34.,vDistance);
     color=mix(color,vec3(.035,.053,.085),fog*.82);
     float alpha=(1.-smoothstep(29.,36.,vDistance))*smoothstep(-3.3,-1.6,vWorld.y);
     gl_FragColor=vec4(color,alpha*vEdge);
    }`);
   program=gl.createProgram();if(!program)throw Error('Program unavailable');gl.attachShader(program,vertex);gl.attachShader(program,fragment);gl.linkProgram(program);
   if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error('Program linking failed');
   // Seeded smooth noise gives stable ridges on every visit.
   const hash=(x:number,z:number)=>{const n=Math.sin(x*127.1+z*311.7)*43758.5453;return n-Math.floor(n);};
   const noise=(x:number,z:number)=>{const ix=Math.floor(x),iz=Math.floor(z);let fx=x-ix,fz=z-iz;fx=fx*fx*(3-2*fx);fz=fz*fz*(3-2*fz);return (hash(ix,iz)*(1-fx)+hash(ix+1,iz)*fx)*(1-fz)+(hash(ix,iz+1)*(1-fx)+hash(ix+1,iz+1)*fx)*fz;};
   const height=(x:number,z:number)=>{
    const peaks=[[2,0,8.2,3.1],[-5,-3,4.5,3.6],[8,-4,5.8,3.4],[-10,-6,3.7,3.1],[0,-7,4.9,3.1]];
    let h=0;for(const [px,pz,tall,spread] of peaks)h=Math.max(h,tall*Math.exp(-Math.hypot((x-px)/spread,(z-pz)/spread)*.9));
    const detail=(noise(x*.8,z*.8)-.5)*.9+(noise(x*2.3,z*2.3)-.5)*.38+(noise(x*5.8,z*5.8)-.5)*.16;
    return h+detail*Math.min(h,2)-2.3;
   };
   const vertices:number[]=[];
   const point=(x:number,z:number)=>[x,height(x,z),z];
   const tri=(a:number[],b:number[],c:number[])=>{
    const u=b.map((v,i)=>v-a[i]),v=c.map((w,i)=>w-a[i]);
    let n=[u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]];const len=Math.hypot(...n);n=n.map(w=>w/len);
    for(const p of [a,b,c])vertices.push(...p,...n);
   };
   const nx=150,nz=100;
   for(let j=0;j<nz;j++)for(let i=0;i<nx;i++){
    const x=-18+i*36/nx,z=-12+j*24/nz,dx=36/nx,dz=24/nz;
    const a=point(x,z),b=point(x+dx,z),c=point(x,z+dz),d=point(x+dx,z+dz);tri(a,c,b);tri(b,c,d);
   }
   buffer=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buffer);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array(vertices),gl.STATIC_DRAW);
   gl.useProgram(program);
   for(const [name,offset] of [['position',0],['normal',12]] as const){const location=gl.getAttribLocation(program,name);gl.enableVertexAttribArray(location);gl.vertexAttribPointer(location,3,gl.FLOAT,false,24,offset);}
   const uniforms=Object.fromEntries(['yaw','pitch','aspect','travel'].map(name=>[name,gl.getUniformLocation(program!,name)]));
   gl.enable(gl.DEPTH_TEST);gl.enable(gl.BLEND);gl.blendFunc(gl.SRC_ALPHA,gl.ONE_MINUS_SRC_ALPHA);gl.clearColor(0,0,0,0);
   let progress=0,mx=0,my=0,angle=-.22,tilt=.13;
   const draw=()=>{
    frame=0;if(disposed||document.hidden)return;
    const target=reduced?-.22:-.22+progress*.68+mx*.10;
    const targetTilt=reduced?.13:.13+progress*.10+my*.035;
    angle+=(target-angle)*.065;tilt+=(targetTilt-tilt)*.065;
    gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
    gl.uniform1f(uniforms.yaw,angle);gl.uniform1f(uniforms.pitch,tilt);gl.uniform1f(uniforms.travel,reduced?0:progress);gl.uniform1f(uniforms.aspect,canvas.clientWidth/canvas.clientHeight);
    gl.drawArrays(gl.TRIANGLES,0,vertices.length/6);
    if(!ready){ready=true;document.documentElement.classList.add('mountain-3d-ready');}
    if(Math.abs(target-angle)+Math.abs(targetTilt-tilt)>.0001)frame=requestAnimationFrame(draw);
   };
   const schedule=()=>{if(!frame&&!disposed)frame=requestAnimationFrame(draw);};
   const resize=()=>{const dpr=Math.min(devicePixelRatio||1,1.5);canvas.width=Math.round(canvas.clientWidth*dpr);canvas.height=Math.round(canvas.clientHeight*dpr);gl.viewport(0,0,canvas.width,canvas.height);schedule();};
   const scroll=()=>{progress=Math.min(1,window.scrollY/Math.max(1,document.documentElement.scrollHeight-innerHeight));schedule();};
   const pointer=(e:PointerEvent)=>{if(e.pointerType!=='mouse'||reduced)return;mx=e.clientX/innerWidth*2-1;my=e.clientY/innerHeight*2-1;schedule();};
   const lost=()=>{disposed=true;document.documentElement.classList.remove('mountain-3d-ready');cancelAnimationFrame(frame);};

   window.addEventListener('resize',resize);window.addEventListener('scroll',scroll,{passive:true});window.addEventListener('pointermove',pointer,{passive:true});document.addEventListener('visibilitychange',schedule);canvas.addEventListener('webglcontextlost',lost);

   resize();scroll();
   return()=>{disposed=true;cancelAnimationFrame(frame);window.removeEventListener('resize',resize);window.removeEventListener('scroll',scroll);window.removeEventListener('pointermove',pointer);document.removeEventListener('visibilitychange',schedule);canvas.removeEventListener('webglcontextlost',lost);document.documentElement.classList.remove('mountain-3d-ready');gl.deleteBuffer(buffer);gl.deleteProgram(program);shaders.forEach(shader=>gl.deleteShader(shader));};
  }catch{gl.deleteBuffer(buffer);gl.deleteProgram(program);shaders.forEach(shader=>gl.deleteShader(shader));}
 },[reduced]);
 return <div className="mountain-scene" aria-hidden="true"><canvas ref={canvasRef}/></div>;
}



