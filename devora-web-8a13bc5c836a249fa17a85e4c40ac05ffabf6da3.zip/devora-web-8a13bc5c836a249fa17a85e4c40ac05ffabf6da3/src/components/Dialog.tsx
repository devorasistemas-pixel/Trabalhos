import {useEffect,useRef,type ReactNode} from 'react';
import {X} from 'lucide-react';
/** Native dialog provides background inertness, focus containment and Esc. */
export default function Dialog({open,onClose,titleId,children,className=''}:{open:boolean;onClose:()=>void;titleId:string;children:ReactNode;className?:string}){
 const ref=useRef<HTMLDialogElement>(null);
 useEffect(()=>{const node=ref.current;if(!open||!node)return;const overflow=document.body.style.overflow;const previous=document.activeElement as HTMLElement|null;node.showModal();document.body.style.overflow='hidden';return()=>{node.close();document.body.style.overflow=overflow;previous?.focus();};},[open]);
 return <dialog ref={ref} className={'detail-dialog '+className} aria-labelledby={titleId} onClose={onClose} onClick={e=>{if(e.target===e.currentTarget)onClose();}}><div className="detail-dialog-inner"><button autoFocus className="detail-close" type="button" aria-label="Fechar janela" onClick={onClose}><X size={20}/></button>{children}</div></dialog>;
}

