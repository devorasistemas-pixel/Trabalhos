import {useEffect, useRef, useState} from 'react';
import {motion, useMotionValue, useSpring, useScroll, useTransform, useReducedMotion, useMotionValueEvent} from 'motion/react';
import './immersive.css';

// A procedural interface sculpture: no external 3D model or WebGL download.
export default function ImmersiveStory(){
 const ref=useRef<HTMLElement>(null);
 const {scrollYProgress:p}=useScroll({target:ref,offset:['start start','end end']});
 const reduced=useReducedMotion();
 const turn=useTransform(p,[0,.5,1],[-24,12,-8]);
 const tilt=useTransform(p,[0,.5,1],[12,-5,8]);
 const rise=useTransform(p,[0,1],[25,-25]);
 const [active,setActive]=useState(0);
 useMotionValueEvent(p,'change',value=>setActive(value<.33?0:value<.67?1:2));


 const steps=[['01 / ESTRATÉGIA','Tudo começa com','uma boa direção.','Entendemos sua marca, seu público e o que o seu negócio precisa alcançar.'],['02 / DESIGN','Sua identidade.','Uma nova dimensão.','Transformamos a essência da sua marca em uma experiência clara, singular e memorável.'],['03 / TECNOLOGIA','Precisão em cada','interação.','Construímos sites e sistemas responsivos, com atenção à velocidade e à experiência de uso.']];
 return <section ref={ref} className={'immersive-story'+(reduced?' story-static':'')} aria-label="Da estratégia à experiência digital">
  <div className="story-pin"><div className="story-intro"><span className="eyebrow">DA IDEIA À EXPERIÊNCIA</span><span>DESLIZE PARA EXPLORAR ↓</span></div>
   <div className="story-stage"><div className="story-copy">{steps.filter((_,i)=>reduced||i===active).map(([label,title,italic,text])=><motion.article key={label} initial={reduced?false:{opacity:0,y:12}} animate={{opacity:1,y:0}} transition={{duration:.4}}><span className="eyebrow">{label}</span><h2>{title}<br/><em>{italic}</em></h2><p>{text}</p></motion.article>)}</div>
   <div className="device-perspective" aria-hidden="true"><div className="device-aura"/><motion.div className="device-shell" style={reduced?{}:{rotateY:turn,rotateX:tilt,y:rise}}><div className="device-top"><span>◢ DEVORA</span><span>ESTÚDIO DIGITAL · 01</span></div><div className="device-screen"><span>FEITO PARA IR ALÉM</span><div className="device-word">Sua marca.<br/><em>Em outro nível.</em></div><div className="device-link">DESIGN + TECNOLOGIA ↗</div><div className="device-orbit"><i/><i/><i/></div></div><div className="device-foot"><span>ESTRATÉGIA</span><span>IDENTIDADE</span><span>EXPERIÊNCIA</span></div></motion.div><span className="device-caption">UMA VISÃO. INFINITAS POSSIBILIDADES.</span></div>
   </div><div className="story-track" aria-hidden="true"><motion.div style={reduced?{}:{scaleX:p}}/></div>
  </div>
 </section>;
}

export function AmbientDepth(){
 const reduced=useReducedMotion();
 const x=useMotionValue(0),y=useMotionValue(0);
 const sx=useSpring(x,{stiffness:35,damping:25}),sy=useSpring(y,{stiffness:35,damping:25});
 const {scrollYProgress}=useScroll();
 const light=useTransform(scrollYProgress,[0,.35,.7,1],[.3,.65,.25,.5]);
 useEffect(()=>{if(reduced||!matchMedia('(pointer:fine)').matches)return;const move=(e:PointerEvent)=>{x.set((e.clientX/innerWidth-.5)*100);y.set((e.clientY/innerHeight-.5)*70);};window.addEventListener('pointermove',move,{passive:true});return()=>window.removeEventListener('pointermove',move);},[reduced,x,y]);
 return <><motion.div className="reading-progress" style={{scaleX:scrollYProgress}} aria-hidden="true"/><motion.div className="ambient-depth" aria-hidden="true" style={reduced?{}:{x:sx,y:sy,opacity:light}}><i/><i/><i/></motion.div></>;
}



