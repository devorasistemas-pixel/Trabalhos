// Original vector artwork for Devora: a digital workspace and the people behind it.
export default function WorkflowIllustration(){return <svg viewBox="0 0 760 580" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false">
 <defs><linearGradient id="wf-ground" x1="150" y1="430" x2="650" y2="550" gradientUnits="userSpaceOnUse"><stop stopColor="#2946C9"/><stop offset="1" stopColor="#5A3CCA"/></linearGradient><linearGradient id="wf-shirt" x1="490" y1="290" x2="510" y2="385" gradientUnits="userSpaceOnUse"><stop stopColor="#FFCF8E"/><stop offset="1" stopColor="#FF9D70"/></linearGradient><filter id="wf-shadow" x="-25%" y="-25%" width="150%" height="170%"><feDropShadow dx="0" dy="19" stdDeviation="14" floodColor="#16247D" floodOpacity=".22"/></filter></defs>
 <ellipse cx="412" cy="467" rx="304" ry="70" fill="#3850D0" opacity=".36"/>
 <path d="M110 420C197 382 255 395 334 429C435 473 508 409 601 403C676 398 733 440 700 487C672 528 531 546 418 525C292 502 205 545 125 504C73 477 71 440 110 420Z" fill="url(#wf-ground)"/>
 <g opacity=".9"><path d="M645 389C660 331 632 284 649 233C665 183 712 185 704 228C699 260 674 294 681 329C692 287 714 261 734 270C756 281 729 328 711 347C690 370 681 395 679 418" fill="#9B92FA"/><path d="M656 412C658 349 675 268 692 218M676 371L720 293" stroke="#C7C4FF" strokeWidth="2" strokeLinecap="round"/>
 <path d="M155 429C131 389 112 359 126 328C141 296 160 313 167 335C163 290 130 267 133 235C136 203 163 205 180 235C197 265 189 320 202 351C197 310 210 281 232 285C256 291 230 339 221 364C214 386 216 421 221 447" fill="#7CCDF4"/><path d="M199 438C199 378 169 294 156 232M181 371L143 338M200 390L222 310" stroke="#C2E8FF" strokeWidth="2" strokeLinecap="round"/>
 <path d="M101 445C99 396 60 363 58 330C57 299 87 294 108 327C130 361 114 389 136 412C125 384 138 359 154 369C174 381 149 425 150 453" fill="#FFCE83"/><path d="M132 455L83 322M113 404L146 386" stroke="#FFF0C9" strokeWidth="2" strokeLinecap="round"/></g>
 <g className="workflow-screen" transform="rotate(-4 402 270)" filter="url(#wf-shadow)">
  <rect x="175" y="84" width="475" height="326" rx="17" fill="#D2DFFB"/>
  <rect x="184" y="73" width="475" height="326" rx="14" fill="#FFF"/>
  <path d="M184 87C184 79.3 190.3 73 198 73H645C652.7 73 659 79.3 659 87V109H184V87Z" fill="#FFD17B"/>
  <circle cx="205" cy="91" r="4" fill="#F49772"/><circle cx="222" cy="91" r="4" fill="#B399F2"/><circle cx="239" cy="91" r="4" fill="#7DABED"/>
  <rect x="203" y="129" width="100" height="247" rx="7" fill="#EFF4FC"/>
  <rect x="217" y="145" width="40" height="6" rx="3" fill="#3E70E6"/><rect x="217" y="173" width="62" height="5" rx="2.5" fill="#C5D4ED"/><rect x="217" y="193" width="46" height="5" rx="2.5" fill="#C5D4ED"/><rect x="217" y="213" width="57" height="5" rx="2.5" fill="#C5D4ED"/>
  <rect x="217" y="254" width="72" height="89" rx="5" fill="#D9E6FC"/><path d="M226 327L243 305L256 314L279 280" stroke="#8BAAE8" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/>
  <rect x="323" y="130" width="144" height="88" rx="8" fill="#F2F6FC"/><rect x="481" y="130" width="157" height="88" rx="8" fill="#F2F6FC"/>
  <rect x="337" y="144" width="64" height="5" rx="2.5" fill="#A6BADD"/><rect x="337" y="168" width="17" height="34" rx="3" fill="#B7CDFB"/><rect x="361" y="157" width="17" height="45" rx="3" fill="#719BF2"/><rect x="385" y="172" width="17" height="30" rx="3" fill="#B5AEF2"/><rect x="409" y="152" width="17" height="50" rx="3" fill="#5386E8"/>
  <circle cx="522" cy="174" r="23" stroke="#D2DFF5" strokeWidth="11"/><path d="M522 151A23 23 0 0 1 542 185" stroke="#8D7DE5" strokeWidth="11"/>
  <rect x="562" y="151" width="57" height="5" rx="2.5" fill="#B7C9E6"/><rect x="562" y="168" width="44" height="5" rx="2.5" fill="#CAD8ED"/><rect x="562" y="185" width="52" height="5" rx="2.5" fill="#CAD8ED"/>
  <rect x="323" y="232" width="315" height="101" rx="8" fill="#F3F7FC"/><path d="M339 309H621M339 285H621M339 261H621" stroke="#E0E8F5"/>
  <path d="M339 303C366 304 369 269 392 277C415 286 430 289 449 272C469 255 487 277 507 262C527 248 544 272 563 251C581 234 601 252 621 240" stroke="#71A0F5" strokeWidth="4" strokeLinecap="round"/>
  <rect x="323" y="350" width="112" height="10" rx="5" fill="#DBE5F5"/><rect x="323" y="368" width="81" height="5" rx="2.5" fill="#E9EFF8"/><rect x="537" y="350" width="101" height="26" rx="13" fill="#6692EB"/>
 </g>
 <ellipse cx="266" cy="491" rx="87" ry="15" fill="#233BB7" opacity=".5"/>
 <path d="M165 462C173 413 233 394 272 428C297 451 304 473 340 482C356 486 355 500 332 506C284 521 213 504 183 487C171 480 163 474 165 462Z" fill="#FFAA9B"/>
 <path d="M212 407C202 421 205 455 226 464L267 474L299 461L260 446L250 406" fill="#4F69E1"/>
 <path d="M241 434L273 442L291 430L304 435L285 455L243 450" fill="#E9B58F"/>
 <path d="M224 463L270 473L305 490L324 486L317 479L276 456" fill="#243258"/><path d="M246 464L281 468L302 477L330 472L335 480L305 488" fill="#344774"/>
 <path d="M323 484L344 482L350 490L328 494Z" fill="#172340"/>
 <path d="M220 405L219 391L239 386L243 408" fill="#DFA181"/><ellipse cx="229" cy="382" rx="17" ry="22" fill="#EDBB98"/>
 <path d="M212 382C204 363 215 352 232 358C247 351 255 369 244 378L229 372L225 383L219 375L217 387" fill="#233358"/>
 <path d="M265 437L310 439L329 466H282Z" fill="#AECBF5"/><path d="M281 466H330L338 471H278Z" fill="#DCF0FF"/>
 <ellipse cx="484" cy="450" rx="44" ry="10" fill="#263AAB" opacity=".5"/>
 <path d="M474 349L469 392L459 437L472 440L488 401L494 369L501 404L514 443L527 440L518 397L514 347" fill="#233456"/>
 <path d="M457 437L473 438L473 448H450Z" fill="#172440"/><path d="M513 439L528 437L540 444L539 449H515Z" fill="#172440"/>
 <path d="M479 282L468 299L474 354C490 364 503 359 518 351L515 302L503 282Z" fill="url(#wf-shirt)"/>
 <path d="M471 299L456 288L438 256L431 257L429 268L449 306L473 321" fill="#F2C2A0"/>
 <path d="M512 300L532 284L551 252L560 255L558 267L540 300L516 322" fill="#F2C2A0"/>
 <path d="M480 283L483 271H498L503 284C500 293 485 295 480 283Z" fill="#DBA17F"/><ellipse cx="491" cy="258" rx="17" ry="21" fill="#EAB795"/>
 <path d="M474 258C465 245 478 231 495 235C515 231 515 261 504 267L502 248L487 250L479 246L481 259" fill="#263658"/>
 <ellipse cx="622" cy="490" rx="52" ry="12" fill="#263AAB" opacity=".5"/>
 <path d="M610 397L597 435L577 465L590 472L615 447L629 419L644 443L661 466L673 458L654 427L643 393" fill="#3C318F"/>
 <path d="M577 464L590 470L589 480L565 472Z" fill="#1F294E"/><path d="M662 462L674 457L683 471L677 478Z" fill="#1F294E"/>
 <path d="M610 337C626 326 641 339 645 355L650 400C636 414 615 412 603 397L607 360" fill="#FFD17B"/>
 <path d="M609 354L593 371L572 372L569 383L600 385L622 364" fill="#C99173"/>
 <path d="M640 349L656 372L645 389L638 383L644 370L631 360" fill="#D5A184"/>
 <path d="M613 338L612 323L630 319L635 340" fill="#BD8469"/><ellipse cx="619" cy="308" rx="18" ry="22" fill="#D3A180"/>
 <path d="M601 311C590 303 594 285 611 283C629 274 640 287 640 303C649 303 662 309 656 319C647 330 629 318 632 304L627 294L609 301L605 315" fill="#4E376D"/>
 <rect x="560" y="353" width="27" height="38" rx="3" transform="rotate(-11 560 353)" fill="#B1CDF8"/><path d="M566 362L580 359M567 369L582 366" stroke="#789CE1" strokeWidth="2"/>
 <circle cx="343" cy="69" r="6" fill="#AFC6FF" opacity=".7"/><circle cx="688" cy="148" r="5" fill="#C8BAFF" opacity=".7"/><path d="M116 214V228M109 221H123" stroke="#B9D7FF" strokeWidth="2" strokeLinecap="round"/>
 </svg>;}

