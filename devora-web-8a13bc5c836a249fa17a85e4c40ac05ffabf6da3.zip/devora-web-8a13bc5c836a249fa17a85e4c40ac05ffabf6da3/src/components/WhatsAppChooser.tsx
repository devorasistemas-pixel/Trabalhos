import {useEffect, useRef, useState} from 'react';
import {MessageCircle, ArrowUpRight, X} from 'lucide-react';
import {REPRESENTATIVES, whatsappLink} from '../config/contact';

export default function WhatsAppChooser() {
  const [open, setOpen] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) return;
    const onKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') { setOpen(false); trigger.current?.focus(); }
    };
    const onOutside = (event: PointerEvent) => {
      if (!root.current?.contains(event.target as Node)) setOpen(false);
    };
    document.addEventListener('keydown', onKey);
    document.addEventListener('pointerdown', onOutside);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.removeEventListener('pointerdown', onOutside);
    };
  }, [open]);

  return <div className="whatsapp-widget" ref={root}>
    {open && <section className="whatsapp-panel" id="whatsapp-representatives" aria-label="Escolha um representante">
      <div className="whatsapp-panel-heading"><div><span>VAMOS CONVERSAR</span><h2>Com quem você quer falar?</h2></div><button onClick={() => {setOpen(false); trigger.current?.focus();}} aria-label="Fechar representantes"><X size={18}/></button></div>
      <p>Escolha um representante para abrir a conversa no WhatsApp.</p>
      {REPRESENTATIVES.map(rep => <a className="representative-option" href={whatsappLink(rep)} target="_blank" rel="noopener noreferrer" key={rep.id} onClick={() => setOpen(false)}><span className="representative-avatar" aria-hidden="true"><img src={rep.image} alt="" /></span><span><strong>{rep.name}</strong><small>Conversar no WhatsApp</small></span><ArrowUpRight size={18}/></a>)}
    </section>}
    <button ref={trigger} type="button" className="whatsapp-float" onClick={() => setOpen(value => !value)} aria-expanded={open} aria-controls="whatsapp-representatives" aria-label={open ? 'Fechar escolha de representante' : 'Escolher representante no WhatsApp'}><MessageCircle size={24}/><span>Chamar no WhatsApp</span></button>
  </div>;
}

