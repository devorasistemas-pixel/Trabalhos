import {useEffect,useState} from 'react';
import {ArrowUpRight} from 'lucide-react';
import {catalog,categories,initialPrice,investment,offerName,offerUrl,quoteUrl,type Offer} from '../config/catalog';
import {commercialLink,INSTAGRAM_URL} from '../config/contact';

const options = [['destaque','Destaque'],['recentes','Mais recentes'],['menor','Menor preço inicial'],['maior','Maior preço inicial'],['az','A–Z']];
const recent = (offer:Offer) => !!offer.publishedAt && Date.now()-Date.parse(offer.publishedAt) >= 0 && Date.now()-Date.parse(offer.publishedAt) < 90*86400000;
const categoryName = (offer:Offer) => categories.find(([id])=>id===offer.category)?.[1];
export function Mockup({offer,variant=0}:{offer:Offer;variant?:number}) {
  return <div className={'editorial-mockup mock-'+offer.category} role="img" aria-label={'Mockup ilustrativo de '+offerName(offer)}>
    <div className="mock-chrome"><i/><i/><i/><span>DEVORA / ESTUDO DE INTERFACE</span></div>
    {offer.category==='landing' ? <div className="mock-landing"><span>ESTÚDIO / APRESENTAÇÃO</span><strong>{variant?'Trabalho com propósito.':'Uma marca, muitas histórias.'}</strong><div className="mock-shape"/><b>Conheça o trabalho ↗</b></div> : offer.category==='sistema' ? <div className="mock-system"><aside>Visão geral<br/>Clientes<br/>Agenda</aside><div><strong>{variant?'Agenda de serviços':'Painel de operações'}</strong><div className="mock-bars">{[42,65,50,78,62,92,72].map((h,i)=><i key={i} style={{height:h+'%'}}/>)}</div><span>Dados ilustrativos</span></div></div> : <div className="mock-chat"><strong>{variant?'Qualificação de contatos':'Atendimento digital'}</strong><p>Olá! Como posso ajudar?</p><p>Quero conhecer os serviços.</p><p>Claro. Qual solução você procura?</p></div>}
  </div>;
}
function Card({offer}:{offer:Offer}) {
  return <article className="editorial-card"><Mockup offer={offer}/><div className="editorial-card-copy">
    <span className="eyebrow">{categoryName(offer)}</span><h3>{offerName(offer)}</h3><p>{offer.description}</p>
    <strong className="offer-price">{investment(offer)}</strong>
    <div className="offer-actions"><a href={offerUrl(offer)}>Ver detalhes <ArrowUpRight size={15}/></a><a href={commercialLink(offer.message)} target="_blank" rel="noopener noreferrer">Conversar no WhatsApp <ArrowUpRight size={15}/></a></div>
  </div></article>;
}
export function Highlights() {
  const news=catalog.filter(recent);
  return <section className="section editorial-section"><span className="eyebrow">EM DESTAQUE</span><h2>Duas formas de <em>ir além.</em></h2><div className="editorial-grid featured-solutions">{catalog.filter(o=>o.featured).map(o=><Card key={o.id} offer={o}/>)}</div>{news.length>0&&<><h2>Novidades</h2><div className="editorial-grid">{news.map(o=><Card key={o.id} offer={o}/>)}</div></>}</section>;
}
export function Technology(){return <section className="section editorial-section technology"><div><span className="eyebrow">TECNOLOGIA</span><h2>Precisão em cada <em>interação.</em></h2></div><p>Desenvolvemos sites e sistemas responsivos com atenção à velocidade, à acessibilidade e à experiência de uso. Cada interface é planejada para funcionar bem no celular e no computador, com uma estrutura que facilita a evolução do projeto.</p></section>;}
export function Follow(){return <section className="section editorial-section"><span className="eyebrow">SIGA-NOS</span><h2>Projetos e <em>bastidores.</em></h2><div className="social-editorial"><a href="/#projetos"><img src="/studio-vip-preview.webp" alt="Prévia do site Studio VIP Lounge" width="1265" height="712" loading="lazy"/>Conheça nossos projetos <ArrowUpRight size={16}/></a><a className="social-text" href={INSTAGRAM_URL} target="_blank" rel="noopener noreferrer"><span className="eyebrow">INSTAGRAM</span><strong>@devoraweb.oficial</strong><span>Acompanhe a Devora <ArrowUpRight size={16}/></span></a></div></section>;}
function readFilters(){return new URLSearchParams(typeof location==='undefined'?'':location.search);}
export function Catalog({home=false}:{home?:boolean}) {
  const [filters,setFilters]=useState(readFilters);
  useEffect(()=>{const sync=()=>setFilters(readFilters());window.addEventListener('popstate',sync);return()=>window.removeEventListener('popstate',sync);},[]);
  function change(key:string,value:string) {
    const next=new URLSearchParams(filters);
    if(value)next.set(key,value);else next.delete(key);
    history.pushState(null,'',location.pathname+(next.size?'?'+next.toString():'')+location.hash);
    setFilters(next);
  }
  const category=categories.some(([id])=>id===filters.get('categoria'))?filters.get('categoria'):'';
  const selection=filters.get('selecao');
  const sort=options.some(([id])=>id===filters.get('ordem'))?filters.get('ordem'):'destaque';
  const offers=home?catalog:catalog.filter(o=>(!category||o.category===category)&&(selection!=='destaques'||o.featured)&&(selection!=='novidades'||recent(o))).sort((a,b)=>{
    if(sort==='menor')return initialPrice(a)-initialPrice(b);
    if(sort==='maior')return initialPrice(b)-initialPrice(a);
    if(sort==='az')return offerName(a).localeCompare(offerName(b),'pt-BR');
    if(sort==='recentes')return (b.publishedAt??'').localeCompare(a.publishedAt??'');
    return Number(b.featured)-Number(a.featured);
  });
  return <section className="section editorial-section" id="precos"><span className="eyebrow">SERVIÇOS E INVESTIMENTO</span>{home?<h2>O próximo passo do seu negócio, <em>com clareza desde o início.</em></h2>:<h1>Serviços e <em>preços.</em></h1>}
    <p>Landing pages, sistemas web e agentes de IA para diferentes momentos do seu negócio.</p>
    {!home&&<div className="catalog-controls"><label>Categoria<select value={category??''} onChange={e=>change('categoria',e.target.value)}><option value="">Todas as categorias</option>{categories.map(([id,name])=><option key={id} value={id}>{name}</option>)}</select></label><label>Seleção<select value={selection==='novidades'||selection==='destaques'?selection:''} onChange={e=>change('selecao',e.target.value)}><option value="">Todos os serviços</option><option value="destaques">Destaques</option><option value="novidades">Novidades</option></select></label><label>Ordenar por<select value={sort??'destaque'} onChange={e=>change('ordem',e.target.value)}>{options.map(([id,name])=><option key={id} value={id}>{name}</option>)}</select></label></div>}
    <div className="editorial-grid">{offers.map(o=><Card key={o.id} offer={o}/>)}</div>
    {!offers.length&&<p role="status">Nenhum serviço corresponde a esta seleção.</p>}
    {home&&<a className="button" href="/servicos/">Explorar catálogo <ArrowUpRight size={16}/></a>}
  </section>;
}
export function Detail({offer}:{offer:Offer}) {
  const related=catalog.filter(o=>o.id!==offer.id).sort((a,b)=>Number(b.category===offer.category)-Number(a.category===offer.category)).slice(0,2);
  const audience=offer.category==='landing'?'Empresas e profissionais que querem apresentar seus serviços e facilitar o primeiro contato.':offer.category==='sistema'?'Equipes que precisam centralizar dados e organizar sua rotina.':'Negócios que querem organizar e automatizar parte do atendimento.';
  return <section className="section editorial-section detail-page"><a className="textlink" href="/servicos/">← Voltar aos serviços</a><span className="eyebrow">{categoryName(offer)}</span><h1>{offerName(offer)}</h1><p>{offer.description}</p><div className="detail-layout"><div><Mockup offer={offer}/><Mockup offer={offer} variant={1}/></div><div><h2>Para quem é</h2><p>{audience}</p><h2>Entregáveis</h2><ul>{offer.features.map(item=><li key={item}>{item}</li>)}</ul><h2>Investimento</h2><strong className="offer-price">{investment(offer)}</strong><ul>{offer.conditions.map(item=><li key={item}>{item}</li>)}</ul><a className="button" href={quoteUrl(offer)}>Solicitar orçamento <ArrowUpRight size={16}/></a></div></div><h2>Serviços relacionados</h2><div className="editorial-grid featured-solutions">{related.map(o=><Card key={o.id} offer={o}/>)}</div></section>;
}
export function AboutPage(){return <section className="section editorial-section"><span className="eyebrow">SOBRE A DEVORA WEB</span><h1>Cada detalhe conta.<br/><em>Cada projeto é único.</em></h1><div className="detail-layout"><div><h2>Nosso propósito</h2><p>A Devora Web é um estúdio digital brasileiro. Nosso trabalho parte da necessidade de cada negócio e combina design, tecnologia e estratégia para transformar ideias em experiências úteis, claras e duradouras.</p><h2>Como trabalhamos</h2><p>Começamos por entender o público e a rotina da empresa. Em seguida, planejamos a experiência, desenvolvemos a solução e testamos a entrega junto ao cliente.</p><h2>Nossos valores</h2><p><b>Inovação</b> para encontrar soluções adequadas. <b>Qualidade</b> nos detalhes da entrega. <b>Compromisso</b> com uma conversa clara em cada etapa.</p><a href={quoteUrl()} className="button">Solicitar orçamento <ArrowUpRight size={16}/></a></div><figure><img src="/studio-vip-preview.webp" width="1265" height="712" alt="Site Studio VIP Lounge desenvolvido pela Devora Web"/><figcaption>Projeto real / Studio VIP Lounge</figcaption></figure></div></section>;}

