import {useEffect,useState} from 'react';
import {Moon,Sun} from 'lucide-react';
const key='devora-theme-v1';
export default function ThemeToggle(){
 const [dark,setDark]=useState(false);
 useEffect(()=>{let saved:string|null=null;try{saved=localStorage.getItem(key);}catch{}setDark(saved==='dark'||(saved!=='light'&&window.matchMedia('(prefers-color-scheme: dark)').matches));},[]);
 useEffect(()=>{document.documentElement.dataset.theme=dark?'dark':'light';},[dark]);
 function toggle(){const next=!dark;setDark(next);try{localStorage.setItem(key,next?'dark':'light');}catch{}}
 return <button className="theme-toggle" type="button" aria-label={dark?'Ativar modo claro':'Ativar modo noturno'} aria-pressed={dark} onClick={toggle}>{dark?<Sun size={20}/>:<Moon size={20}/>}</button>;
}
