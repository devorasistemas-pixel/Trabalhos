import {useEffect,useState} from 'react';
import {ShieldCheck} from 'lucide-react';
import Dialog from './Dialog';
export const CONSENT_KEY='devora:privacy:v1';
const MAX_AGE=180*24*60*60*1000;
export type ConsentChoice={version:1;optional:boolean;updatedAt:number};
export function readConsent():ConsentChoice|null{try{const raw=localStorage.getItem(CONSENT_KEY);if(!raw)return null;const value=JSON.parse(raw);return value.version===1&&typeof value.optional==='boolean'&&typeof value.updatedAt==='number'&&Date.now()-value.updatedAt<MAX_AGE&&value.updatedAt<=Date.now()?value:null;}catch{return null;}}
// No optional trackers are installed. Future optional integrations must check this gate.
export function optionalConsentGranted(){return readConsent()?.optional===true;}
export default function Consent(){
 const [visible,setVisible]=useState(false),[open,setOpen]=useState(false),[optional,setOptional]=useState(false),[status,setStatus]=useState('');
 useEffect(()=>{const choice=readConsent();setVisible(!choice);setOptional(choice?.optional??false);const show=()=>{setOpen(true);setStatus('');};window.addEventListener('devora:privacy',show);if(location.hash==='#cookies')show();return()=>window.removeEventListener('devora:privacy',show);},[]);
 useEffect(()=>{if(!status)return;const timeout=window.setTimeout(()=>setStatus(''),6000);return()=>window.clearTimeout(timeout);},[status]);
 useEffect(()=>{
   const banner=document.querySelector('.consent-banner');
   if(!visible||!banner)return;
   const measure=()=>document.documentElement.style.setProperty('--consent-height',banner.getBoundingClientRect().height+'px');
   const observer=new ResizeObserver(measure);
   observer.observe(banner);
   measure();
   return()=>{observer.disconnect();document.documentElement.style.removeProperty('--consent-height');};
 },[visible]);
 function save(value:boolean){const choice:ConsentChoice={version:1,optional:value,updatedAt:Date.now()};try{localStorage.setItem(CONSENT_KEY,JSON.stringify(choice));setStatus('Preferências salvas. Você pode alterá-las no rodapé.');}catch{setStatus('Preferência aplicada nesta visita. Seu navegador não permitiu salvar no dispositivo.');}setOptional(value);setVisible(false);setOpen(false);}
 return <><p className="privacy-status" role="status">{status}</p>{visible&&<section className="consent-banner" aria-labelledby="consent-title"><div><ShieldCheck size={22} aria-hidden="true"/><div><h2 id="consent-title">Sua privacidade, suas escolhas.</h2><p>Guardamos sua preferência neste dispositivo. Não usamos cookies de publicidade ou medição nesta versão. Recursos opcionais dependem da sua autorização. <a href="/politica-de-cookies/">Política de Cookies</a></p></div></div><div className="consent-actions"><button onClick={()=>save(true)}>Aceitar opcionais</button><button onClick={()=>save(false)}>Rejeitar opcionais</button><button onClick={()=>setOpen(true)}>Personalizar</button></div></section>}
 <Dialog open={open} onClose={()=>setOpen(false)} titleId="consent-settings-title" className="consent-dialog"><span className="eyebrow">PRIVACIDADE</span><h2 id="consent-settings-title">Suas preferências</h2><p>Você pode navegar normalmente ao rejeitar recursos opcionais.</p><div className="consent-category"><label><span><b>Armazenamento necessário</b><small>Registra apenas sua escolha de privacidade por até 180 dias. Não contém dados de contato.</small></span><input type="checkbox" checked disabled aria-label="Armazenamento necessário, sempre ativo"/></label></div><div className="consent-category"><label><span><b>Recursos opcionais</b><small>Nenhum rastreador, pixel ou ferramenta de análise está instalado. A escolha é registrada, sem instalar cookies ou ativar serviços de terceiros.</small></span><input type="checkbox" checked={optional} onChange={e=>setOptional(e.target.checked)} aria-label="Permitir recursos opcionais"/></label></div><div className="consent-links"><a href="/politica-de-privacidade/">Política de Privacidade</a><a href="/politica-de-cookies/">Política de Cookies</a></div><button className="button" onClick={()=>save(optional)}>Salvar preferências</button></Dialog></>;
}
export function PrivacySettingsButton(){return <button type="button" className="privacy-settings-link" onClick={()=>window.dispatchEvent(new Event('devora:privacy'))}>Configurações de privacidade</button>;}


