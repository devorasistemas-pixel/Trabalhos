import {motion} from 'motion/react';
import {ArrowUpRight} from 'lucide-react';

const clients=[
 {name:'Studio VIP Lounge',category:'SITE PROFISSIONAL · SALÃO DE BELEZA',image:'/studio-vip-preview.webp',url:'/projetos/studio-vip/',description:'Uma apresentação elegante dos serviços, da equipe e dos trabalhos do studio, com destaque para noivas e agendamento pelo WhatsApp.'},
 {name:'Clínica IPN',category:'SITE INSTITUCIONAL · SAÚDE E BEM-ESTAR',image:'/ipn-preview.jpg',url:'https://experienciaipn.com.br/',description:'Uma experiência institucional acolhedora, com fotografia real, navegação clara e foco na confiança da paciente.'}
];
export default function ClientProjects(){return <div className="client-projects">{clients.map(client=><motion.div key={client.name} className="featured-project" initial={{opacity:0,y:18}} whileInView={{opacity:1,y:0}} viewport={{once:true,amount:.12}} transition={{duration:.55}}>
 <a href={client.url} target="_blank" rel="noopener noreferrer" className="featured-project-image" aria-label={'Visitar o site '+client.name}><img src={client.image} alt={'Prévia do site '+client.name} width="1280" height="800" loading="lazy" decoding="async"/><span>PROJETO REAL</span></a>
 <div className="featured-project-copy"><span className="eyebrow">{client.category}</span><h3>{client.name}</h3><p>{client.description}</p><a className="textlink" href={client.url} target="_blank" rel="noopener noreferrer">Visitar projeto <ArrowUpRight size={17}/></a></div>
 </motion.div>)}</div>;}
