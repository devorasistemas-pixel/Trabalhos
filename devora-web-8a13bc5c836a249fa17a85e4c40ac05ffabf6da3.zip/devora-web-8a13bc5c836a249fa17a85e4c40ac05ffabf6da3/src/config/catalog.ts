import {plans, type Plan} from './plans';

export const categories = [
  ['landing','Landing pages'], ['sistema','Sistemas web'], ['ia','Agentes de IA'],
] as const;
const slugs = ['landing-page-normal','landing-page-premium','sistema-web-personalizado','agentes-de-ia','assistente-whatsapp'];
export const catalog = plans.map((plan,index) => ({
  ...plan,
  slug: slugs[index],
  category: index < 2 ? 'landing' : index === 2 ? 'sistema' : 'ia',
  featured: index === 1 || index === 2,
  publishedAt: null as string | null,
}));
export type Offer = typeof catalog[number];
export const offerName = (offer:Plan) => offer.name + ' ' + offer.tier;
export const offerUrl = (offer:Offer) => '/servicos/' + offer.slug + '/';
export const quoteUrl = (offer?:Offer) => '/contato/' + (offer ? '?servico=' + offer.slug : '');
export const investment = (offer:Plan) =>
  (offer.from ? 'A partir de ' : '') + 'R$ ' + offer.price +
  (offer.id === 'whatsapp' ? '/mês' : offer.recurring ? ' + R$ ' + offer.recurring + '/mês' : '');
export const initialPrice = (offer:Plan) => Number(offer.price.replaceAll('.','').replace(',','.'));
export function pageMeta(path:string) {
  const offer = catalog.find(item => offerUrl(item) === path);
  if (offer) return {title:offerName(offer),description:offer.description};
  if (path === '/servicos/') return {title:'Serviços e preços',description:'Compare as soluções da Devora Web e escolha o próximo passo para seu negócio.'};
  if (path === '/sobre/') return {title:'Sobre nós',description:'Conheça o propósito, o método de trabalho e os valores da Devora Web.'};
  if (path === '/contato/') return {title:'Contato e orçamento',description:'Conte sua ideia e escolha com quem conversar na Devora Web.'};
  return null;
}

