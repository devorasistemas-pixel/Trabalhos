export type Representative = {id: string; name: string; whatsappNumber: string; image: string};
export const REPRESENTATIVES: readonly Representative[] = [
  {id: 'kauan', name: 'Kauan Tonelli', whatsappNumber: '5543998229880', image: '/representatives/kauan.jpg'},
  {id: 'alisson', name: 'Alisson Gomes', whatsappNumber: '5544999854862', image: '/representatives/alisson.jpg'},
];
export const CONTACT_EMAIL: string = '';
export const INSTAGRAM_URL: string = 'https://www.instagram.com/devoraweb.oficial/';
export const projectContact = '#representantes';
export function whatsappLink(representative: Representative, message = 'Olá! Quero conversar sobre meu projeto.') {
  return 'https://wa.me/' + representative.whatsappNumber.replace(/\D/g, '') + '?text=' + encodeURIComponent(message);
}
export const COMMERCIAL_NUMBER = '5543998229880';
export function commercialLink(message = 'Olá! Quero solicitar um orçamento para meu projeto.') { return 'https://wa.me/' + COMMERCIAL_NUMBER + '?text=' + encodeURIComponent(message); }


