import React from 'react';import {createRoot} from 'react-dom/client';import App from './LegacyEntry';createRoot(document.getElementById('root')!).render(<App/>);
